package frc.robot.subsystems;

import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class ReportingSubsystem extends SubsystemBase {
    /** Cria um novo exemplo do Sistema. */
    public ReportingSubsystem() {}
  
    @Override
    public void periodic() {
      // Este método será chamado uma vez por execução de execução
    }
  
    @Override
    public void simulationPeriodic() {
      // Este método será chamado uma vez por agendador executado durante a simulação
    }
}